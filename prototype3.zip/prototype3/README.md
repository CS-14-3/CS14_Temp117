# Prototype 2.0 Researcher and Participant Flow

This repository contains a local Prototype 2.0 bridge that connects:

- researcher sign up and login,
- researcher post editing and publishing,
- participant invite-code entry,
- participant camera calibration,
- participant social-style post viewing.

The original researcher editing backend and camera backend remain in their own folders. The bridge starts them and exposes only two user-facing URLs.

## Requirements

- Python 3.10, 3.11, or 3.12. Python 3.11 is recommended.
- A webcam and browser camera permission for the participant calibration flow.
- Internet access during first setup so Python packages can be installed.

## Quick Start

From the repository root:

```bash
python3.11 run_prototype2.py
```

If your machine uses another supported Python command, this also works:

```bash
python3 run_prototype2.py
```

The runner creates a local `.venv`, installs `requirements.txt`, and starts the bridge.

Open only these two URLs:

- Researcher: `http://127.0.0.1:8120/`
- Participant: `http://127.0.0.1:8121/`

Internal services are started by the bridge:

- researcher scraper backend: `127.0.0.1:5001`
- camera backend: `127.0.0.1:5050`

## Full Demo Flow

1. Open the Researcher URL.
2. Click `Sign up`.
3. Create a prototype account with name, email, and password.
4. Return to the login page and log in with the same email and password.
5. In the editor, choose a platform style: Instagram, Facebook, X, or TikTok.
6. Add or fetch post content, then click `Publish Survey Link`.
7. Copy the generated participant invite code or open the participant link shown after publishing.
8. Open the Participant URL.
9. Enter the invite code.
10. Complete the camera calibration page.
11. Start the study. The participant page shows posts only in the matching social-style module selected by the researcher.

## Runtime Files

These files are generated locally and are intentionally not committed:

- `prototype2.0/fake_researcher_accounts.json`
- `prototype2.0/published_posts.json`
- `CS14_Temp117-Backend/data/`
- `CS14_Temp117-Backend/.runtime_cache/`
- `.venv/`

Deleting the two JSON files resets prototype accounts and published posts.

## Useful Commands

Run the bridge directly after installing dependencies:

```bash
python prototype2.0/bridge.py
```

Use custom ports:

```bash
python prototype2.0/bridge.py --researcher-port 8120 --participant-port 8121 --camera-port 5050
```

Check Python syntax:

```bash
python -m py_compile prototype2.0/bridge.py run_prototype2.py
```

## Troubleshooting

If package installation fails, confirm you are using Python 3.10, 3.11, or 3.12. MediaPipe may not provide wheels for newer Python versions.

If the participant calibration cannot use the camera, allow camera permission in the browser and close other apps that may already be using the webcam.

If a port is already in use, stop the old terminal run with `Ctrl+C`, then start again. On macOS, you can check which process is using a port:

```bash
lsof -nP -iTCP:8120 -sTCP:LISTEN
```

Then stop that process:

```bash
kill <PID>
```

You can also pass different bridge ports:

```bash
python run_prototype2.py --researcher-port 8122 --participant-port 8123
```
