from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, backref, mapped_column, relationship

from db import Base


class Calibration(Base):
    """One calibration session tied to a study session.

    calibration_result stores the outcome label, e.g. "passed" or "failed".
    accuracy_score is the overall quality score (0.0 – 1.0).
    """

    __tablename__ = "calibrations"

    calibration_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_id: Mapped[int] = mapped_column(
        ForeignKey("study_sessions.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )

    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    ended_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    calibration_result: Mapped[str | None] = mapped_column(String(50), nullable=True)
    accuracy_score: Mapped[float | None] = mapped_column(Float, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    study_session: Mapped["StudySession"] = relationship(
        "StudySession",
        backref=backref("calibrations", cascade="all, delete-orphan"),
    )
    calibration_points: Mapped[list["CalibrationPoint"]] = relationship(
        "CalibrationPoint",
        back_populates="calibration",
        cascade="all, delete-orphan",
    )


class CalibrationPoint(Base):
    """Per-point measurement within a calibration session.

    target_x / target_y  — the screen position the participant was asked to fixate.
    measured_x / measured_y — the iris position recorded at that moment.
    All coordinates are normalised (0.0 – 1.0).
    """

    __tablename__ = "calibration_points"

    point_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    calibration_id: Mapped[int] = mapped_column(
        ForeignKey("calibrations.calibration_id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )

    point_order: Mapped[int | None] = mapped_column(Integer, nullable=True)
    target_x: Mapped[float | None] = mapped_column(Float, nullable=True)
    target_y: Mapped[float | None] = mapped_column(Float, nullable=True)
    measured_x: Mapped[float | None] = mapped_column(Float, nullable=True)
    measured_y: Mapped[float | None] = mapped_column(Float, nullable=True)

    calibration: Mapped["Calibration"] = relationship(
        "Calibration",
        back_populates="calibration_points",
    )


class GazeRecord(Base):
    """A single gaze sample recorded during the survey phase.

    post_id links the sample to the specific post the participant was viewing,
    enabling post-level gaze analysis.
    gaze_x / gaze_y are normalised iris coordinates (0.0 – 1.0).
    """

    __tablename__ = "gaze_records"

    gaze_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_id: Mapped[int] = mapped_column(
        ForeignKey("study_sessions.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )
    post_id: Mapped[int | None] = mapped_column(
        ForeignKey("survey_posts.post_id", ondelete="SET NULL"),
        index=True,
        nullable=True,
    )

    timestamp: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    gaze_x: Mapped[float | None] = mapped_column(Float, nullable=True)
    gaze_y: Mapped[float | None] = mapped_column(Float, nullable=True)

    study_session: Mapped["StudySession"] = relationship(
        "StudySession",
        backref=backref("gaze_records", cascade="all, delete-orphan"),
    )
