from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db import Base


class Participant(Base):
    __tablename__ = "participants"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    participant_code: Mapped[str | None] = mapped_column(
        String(64),
        unique=True,
        index=True,
        nullable=True,
    )
    language: Mapped[str | None] = mapped_column(String(32), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    study_sessions: Mapped[list["StudySession"]] = relationship(
        "StudySession",
        back_populates="participant",
        cascade="all, delete-orphan",
    )


class StudySession(Base):
    __tablename__ = "study_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    participant_id: Mapped[int] = mapped_column(
        ForeignKey("participants.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )
    survey_id: Mapped[int] = mapped_column(
        ForeignKey("surveys.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )

    invite_code_used: Mapped[str | None] = mapped_column(String(20), nullable=True)
    session_status: Mapped[str] = mapped_column(String(20), nullable=False, default="started")
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    participant: Mapped["Participant"] = relationship(
        "Participant",
        back_populates="study_sessions",
    )
    survey: Mapped["Survey"] = relationship(
        "Survey",
        back_populates="study_sessions",
    )

    responses: Mapped[list["SurveyResponse"]] = relationship(
        "SurveyResponse",
        back_populates="study_session",
        cascade="all, delete-orphan",
    )

    # 预留给 gaze_models.py 的反向关系
    calibration_results: Mapped[list["CalibrationResult"]] = relationship(
        "CalibrationResult",
        back_populates="study_session",
        cascade="all, delete-orphan",
    )
    raw_payloads: Mapped[list["RawPayload"]] = relationship(
        "RawPayload",
        back_populates="study_session",
        cascade="all, delete-orphan",
    )


class SurveyResponse(Base):
    __tablename__ = "survey_responses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    study_session_id: Mapped[int] = mapped_column(
        ForeignKey("study_sessions.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )

    question_key: Mapped[str | None] = mapped_column(String(100), nullable=True)
    response_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    response_value: Mapped[dict | list | str | int | float | bool | None] = mapped_column(JSONB, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    study_session: Mapped["StudySession"] = relationship(
        "StudySession",
        back_populates="responses",
    )