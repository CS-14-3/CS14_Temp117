from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db import Base


class Survey(Base):
    __tablename__ = "surveys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    researcher_id: Mapped[int] = mapped_column(
        ForeignKey("researchers.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )

    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    news_link: Mapped[str | None] = mapped_column(Text, nullable=True)
    post_caption: Mapped[str | None] = mapped_column(Text, nullable=True)

    simulated_likes: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    simulated_comments: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    invite_code: Mapped[str | None] = mapped_column(
        String(20),
        unique=True,
        index=True,
        nullable=True,
    )
    survey_link: Mapped[str | None] = mapped_column(Text, nullable=True)

    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft")
    is_published: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    researcher: Mapped["Researcher"] = relationship(
        "Researcher",
        back_populates="surveys",
    )

    publish_logs: Mapped[list["SurveyPublishLog"]] = relationship(
        "SurveyPublishLog",
        back_populates="survey",
        cascade="all, delete-orphan",
    )

    # 预留给 participant_models.py 使用
    study_sessions: Mapped[list["StudySession"]] = relationship(
        "StudySession",
        back_populates="survey",
    )


class SurveyPublishLog(Base):
    __tablename__ = "survey_publish_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    survey_id: Mapped[int] = mapped_column(
        ForeignKey("surveys.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )
    published_by: Mapped[int] = mapped_column(
        ForeignKey("researchers.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )

    action: Mapped[str] = mapped_column(String(50), nullable=False, default="publish")
    published_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    survey: Mapped["Survey"] = relationship(
        "Survey",
        back_populates="publish_logs",
    )