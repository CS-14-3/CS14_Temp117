# Researcher and Participant Study Prototype

A local web prototype for running researcher-led social media study sessions. The project connects a researcher authoring interface, invite-code publishing, participant onboarding, camera calibration, and a participant feed styled after common social platforms.

The prototype is designed for local demos, usability testing, and research workflow development. It is not a production authentication, storage, or eye-tracking system.

## Features

- Researcher sign-up and login flow
- Researcher post editor with A/B version controls
- News link metadata fetching for title and image previews
- Platform-style previews for Instagram, Facebook, X, and TikTok
- Invite-code based participant access
- Participant camera calibration flow
- MediaPipe-based face landmark processing through a local Socket.IO backend
- Participant feed rendering based on the platform selected by the researcher
- Local JSON storage for researcher accounts, published posts, and participant study data

## Project Structure

```text
.
|-- run_prototype.py
|-- requirements.txt
|-- bridge/
|   |-- bridge.py
|   |-- fake_researcher_accounts.json
|   `-- published_posts.json
|-- researcher login/
|   |-- researcher-login.html
|   |-- researcher-register.html
|   |-- researcher-login.js
|   |-- researcher-register.js
|   `-- researcher-login.css
|-- researcher main/
|   |-- index.html
|   |-- app.js
|   |-- style.css
|   |-- server.py
|   `-- requirements.txt
`-- CS14_Temp117-Backend/
    |-- app.py
    |-- participant.html
    `-- face_landmarker.task
```

### Main Components

- `run_prototype.py` creates the local virtual environment, installs dependencies, and starts the bridge.
- `bridge/bridge.py` serves the researcher and participant entry points, handles local sessions, publishes posts, and validates invite codes.
- `researcher main/server.py` provides the news metadata scraping API.
- `CS14_Temp117-Backend/app.py` runs the camera, MediaPipe, and Socket.IO backend.
- `CS14_Temp117-Backend/participant.html` contains the participant onboarding, calibration, feed, and data export interface.

## Requirements

- Python 3.11 is recommended.
- Python 3.12 is also supported by the launcher.
- macOS, Linux, and Windows 10/11 are supported as long as Python and the required packages install successfully.
- A webcam is required for the participant calibration flow.
- Browser camera permission must be granted for `127.0.0.1`.
- Internet access is required during first setup to install Python packages.
- Internet access is also useful for CDN assets and news metadata fetching.

MediaPipe can be sensitive to Python version support. If dependency installation fails, try Python 3.11 first.

On Windows, the commands below use the Python Launcher (`py`), which is included when Python is installed from python.org. If `py` is not available, use `python` after confirming it points to Python 3.11 or 3.12.

Check your Python version:

macOS / Linux:

```bash
python3.11 --version
```

Windows PowerShell:

```powershell
py -3.11 --version
```

## Quick Start

After downloading or cloning the repository, open a terminal in the repository root. This is the folder that contains `run_prototype.py`.

macOS / Linux:

```bash
python3.11 run_prototype.py
```

Windows PowerShell:

```powershell
py -3.11 run_prototype.py
```

If your default Python command already points to Python 3.11 or 3.12, these also work:

```bash
python3 run_prototype.py
```

```powershell
python run_prototype.py
```

The launcher will:

1. Create a local `.venv`
2. Install `requirements.txt`
3. Start the bridge
4. Start the researcher scraping backend
5. Start the camera backend
6. Print the researcher and participant URLs

Open the two public-facing local URLs:

- Researcher: `http://127.0.0.1:8120/`
- Participant: `http://127.0.0.1:8121/`

Internal services are started automatically:

- Scraper API: `127.0.0.1:5001`
- Camera backend: `127.0.0.1:5050`

Stop the prototype with `Ctrl+C` in the terminal.

## Demo Flow

### Researcher

1. Open `http://127.0.0.1:8120/`.
2. Create a local researcher account from the sign-up page.
3. Log in with the same email and password.
4. Choose `Version A` or `Version B`.
5. Optionally paste a public news URL and click `Fetch Image`.
6. Choose a platform style: Instagram, Facebook, X, or TikTok.
7. Edit the caption, likes, comments, and shares.
8. Click `Generate Invite Code`.
9. Click `Publish Survey Link`.
10. Copy the generated invite code or participant link.

### Participant

1. Open `http://127.0.0.1:8121/`.
2. Enter the invite code, or open the generated participant link.
3. Allow browser camera access.
4. Complete the calibration flow.
5. Start the study and browse the rendered post feed.
6. Use the platform rail to switch between published platform styles for the invite code.
7. Interact with posts or export the collected JSON data.

## Useful Commands

Run with custom ports:

macOS / Linux:

```bash
python3 run_prototype.py --researcher-port 8122 --participant-port 8123 --camera-port 5051
```

Windows PowerShell:

```powershell
py -3.11 run_prototype.py --researcher-port 8122 --participant-port 8123 --camera-port 5051
```

Run the bridge without auto-starting internal backends:

macOS / Linux:

```bash
python3 bridge/bridge.py --no-backends
```

Windows PowerShell:

```powershell
py -3.11 bridge/bridge.py --no-backends
```

Check Python syntax:

macOS / Linux:

```bash
python3 -m py_compile run_prototype.py bridge/bridge.py "researcher main/server.py" CS14_Temp117-Backend/app.py
```

Windows PowerShell:

```powershell
py -3.11 -m py_compile run_prototype.py bridge/bridge.py "researcher main/server.py" CS14_Temp117-Backend/app.py
```

## Runtime Data

The prototype stores runtime data locally:

- `bridge/fake_researcher_accounts.json` stores local researcher accounts.
- `bridge/published_posts.json` stores published posts and invite codes.
- `CS14_Temp117-Backend/data/` stores participant calibration, gaze, and interaction logs.
- `CS14_Temp117-Backend/.runtime_cache/` stores runtime cache files.
- `.venv/` stores the local Python virtual environment.

To reset local researcher accounts and published posts, stop the server and remove the JSON stores:

macOS / Linux:

```bash
rm bridge/fake_researcher_accounts.json bridge/published_posts.json
```

Windows PowerShell:

```powershell
Remove-Item bridge\fake_researcher_accounts.json, bridge\published_posts.json -ErrorAction SilentlyContinue
```

The bridge recreates empty stores on the next run.

To clear participant recordings, remove the generated `CS14_*.json` files from:

```text
CS14_Temp117-Backend/data/
```

Windows PowerShell:

```powershell
Remove-Item CS14_Temp117-Backend\data\CS14_*.json -ErrorAction SilentlyContinue
```

## Security Notes

This project is a local research prototype.

- Do not use the included login flow for production authentication.
- Do not store real passwords in the local JSON account file.
- Do not commit participant data, private researcher accounts, or generated runtime files to a public repository.
- The news scraping service rejects local and private network URLs as a basic SSRF protection measure.

## Troubleshooting

### Dependency installation fails

Use Python 3.11.

macOS / Linux:

```bash
python3.11 run_prototype.py
```

Windows PowerShell:

```powershell
py -3.11 run_prototype.py
```

If you are using a newer Python release, MediaPipe or OpenCV wheels may not be available for your platform.

### A port is already in use

Find the process using the port:

macOS / Linux:

```bash
lsof -nP -iTCP:8120 -sTCP:LISTEN
```

Windows PowerShell:

```powershell
netstat -ano | findstr :8120
```

Stop the process:

macOS / Linux:

```bash
kill <PID>
```

Windows PowerShell:

```powershell
taskkill /PID <PID> /F
```

Or run the prototype on different ports:

macOS / Linux:

```bash
python3 run_prototype.py --researcher-port 8122 --participant-port 8123
```

Windows PowerShell:

```powershell
py -3.11 run_prototype.py --researcher-port 8122 --participant-port 8123
```

### The camera does not work

- Allow camera access in the browser.
- Close other apps that may be using the webcam.
- Confirm the camera backend is running on the expected port.
- Try refreshing the participant page after granting permission.

### News metadata fetching fails

- Confirm the researcher scraper backend started successfully.
- Use a public `http` or `https` URL.
- Some websites block scraping or omit Open Graph / Twitter metadata.
- Localhost and private network URLs are intentionally rejected.

### The invite code is not accepted

- Make sure the researcher clicked `Publish Survey Link`, not only `Generate Invite Code`.
- Check that the participant entered the same invite code shown after publishing.
- Confirm the published post still exists in `bridge/published_posts.json`.

## Limitations

- Authentication is only a local demo flow.
- Data is stored in local JSON files, not a database.
- News scraping depends on each website's metadata and access rules.
- Gaze and face-landmark data quality depends on camera quality, lighting, participant position, and MediaPipe detection.
- The prototype is intended for local research workflow validation, not production deployment.
