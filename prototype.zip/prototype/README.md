# Prototype

This folder is the GitHub-ready package for the researcher-to-CS14 participant prototype.

## Included

- `cs14_page_connection.py`: main bridge script
- `researcher login/`: researcher login page assets
- `researcher main/`: researcher dashboard assets and scrape backend
- `CS14_Temp117-Backend/`: participant page, eye-tracking backend, and model file

## Before You Run

This project should be set up with Python 3.11 because the CS14 backend depends on `mediapipe`, which is version-sensitive.

Check that Python 3.11 is available:

```bash
python3.11 --version
```

## One-Time Setup

From this `prototype` directory:

```bash
chmod +x setup.sh
./setup.sh
```

That script creates:

- `researcher main/.venv`
- `CS14_Temp117-Backend/.venv`

and installs the required packages from the local `requirements.txt` files.

## Run

```bash
python3 cs14_page_connection.py
```

Default browser entry points:

- Researcher login: `http://127.0.0.1:8020/login`
- Participant page: `http://127.0.0.1:8021/`

Only the participant URL above needs to be shared with participants.

## Notes

- `.venv`, runtime output, and local post storage are intentionally excluded from Git.
- `CS14_Temp117-Backend/face_landmarker.task` is included so the participant backend does not need to download it on first run.
- Researcher fetch depends on `researcher main/server.py`.
- Participant calibration and eye tracking depend on `CS14_Temp117-Backend/app.py`.
