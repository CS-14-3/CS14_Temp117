#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3.11}"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "Python 3.11 is required. Set PYTHON_BIN to a Python 3.11 executable and run again." >&2
  exit 1
fi

echo "Using Python: $PYTHON_BIN"

"$PYTHON_BIN" -m venv "$ROOT_DIR/researcher main/.venv"
"$ROOT_DIR/researcher main/.venv/bin/pip" install --upgrade pip
"$ROOT_DIR/researcher main/.venv/bin/pip" install -r "$ROOT_DIR/researcher main/requirements.txt"

"$PYTHON_BIN" -m venv "$ROOT_DIR/CS14_Temp117-Backend/.venv"
"$ROOT_DIR/CS14_Temp117-Backend/.venv/bin/pip" install --upgrade pip
"$ROOT_DIR/CS14_Temp117-Backend/.venv/bin/pip" install -r "$ROOT_DIR/CS14_Temp117-Backend/requirements.txt"

echo
echo "Setup complete."
echo "Run the bridge with:"
echo "  cd \"$ROOT_DIR\""
echo "  python3 cs14_page_connection.py"
