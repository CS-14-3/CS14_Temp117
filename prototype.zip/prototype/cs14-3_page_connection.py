#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import base64
import json
import mimetypes
import os
import re
import signal
import socket
import subprocess
import sys
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qs, quote, unquote, urlparse


ROOT_DIR = Path(__file__).resolve().parent
COOKIE_NAME = "researcher_bridge_session"
STORAGE_KEY = "__researcher_bridge_session__"
COOKIE_MAX_AGE = 60 * 60 * 12
ASSET_PREFIX = "/__bridge_assets/"
SKIP_DIR_NAMES = {
    ".git",
    ".idea",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "node_modules",
    "venv",
}
ASSET_TAG_PATTERNS = (
    re.compile(r'(<script\b[^>]*\bsrc=["\'])([^"\']+)(["\'])', re.IGNORECASE),
    re.compile(r'(<link\b[^>]*\bhref=["\'])([^"\']+)(["\'])', re.IGNORECASE),
    re.compile(r'(<img\b[^>]*\bsrc=["\'])([^"\']+)(["\'])', re.IGNORECASE),
    re.compile(r'(<source\b[^>]*\bsrc=["\'])([^"\']+)(["\'])', re.IGNORECASE),
)
STORE_PATH = ROOT_DIR / ".published_posts_store.json"
PARTICIPANT_ROUTE = "/participant"
DEFAULT_CS14_PARTICIPANT_ENTRY = ROOT_DIR / "CS14_Temp117-Backend" / "participant.html"
DEFAULT_CS14_BACKEND_FILE = ROOT_DIR / "CS14_Temp117-Backend" / "app.py"


@dataclass(frozen=True)
class PageTarget:
    kind: str
    entry: Path

    @property
    def directory(self) -> Path:
        return self.entry.parent


def iter_project_files(root: Path, suffixes: Iterable[str]) -> list[Path]:
    normalized_suffixes = tuple(suffixes)
    results: list[Path] = []

    for current_root, dir_names, file_names in os.walk(root):
        dir_names[:] = [
            dir_name
            for dir_name in dir_names
            if dir_name not in SKIP_DIR_NAMES and not dir_name.startswith(".")
        ]

        base = Path(current_root)
        for file_name in file_names:
            if file_name.startswith("."):
                continue
            if normalized_suffixes and not file_name.endswith(normalized_suffixes):
                continue
            results.append(base / file_name)

    return results


def load_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def inject_before_body_end(html_text: str, injected: str) -> str:
    marker = "</body>"
    if marker in html_text:
        return html_text.replace(marker, f"{injected}\n{marker}", 1)
    return f"{html_text}\n{injected}\n"


def inject_before_head_end(html_text: str, injected: str) -> str:
    marker = "</head>"
    if marker in html_text:
        return html_text.replace(marker, f"{injected}\n{marker}", 1)
    return f"{injected}\n{html_text}"


def json_for_script(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False).replace("</", "<\\/")


def has_password_input(html_text: str) -> bool:
    lower = html_text.lower()
    return 'type="password"' in lower or "type='password'" in lower or "current-password" in lower


def has_email_input(html_text: str) -> bool:
    lower = html_text.lower()
    return 'type="email"' in lower or "type='email'" in lower or 'autocomplete="email"' in lower


def score_login_html(path: Path, html_text: str) -> int:
    lower = html_text.lower()
    score = 0

    if has_password_input(html_text):
        score += 45
    if has_email_input(html_text):
        score += 30
    if "<form" in lower:
        score += 12
    if "log in" in lower or "login" in lower or "sign in" in lower:
        score += 20
    if "forgot password" in lower:
        score += 10
    if "data-login-root" in lower:
        score += 20
    if "researcher-login-form" in lower:
        score += 8
    if "dashboard" in lower and "preview" in lower:
        score -= 10
    return score


def score_dashboard_html(path: Path, html_text: str) -> int:
    lower = html_text.lower()
    score = 0

    if has_password_input(html_text):
        score -= 40
    if "preview-container" in lower:
        score += 30
    if "input-news-link" in lower or "btn-fetch-news" in lower:
        score += 25
    if "survey" in lower or "dashboard" in lower or "admin" in lower:
        score += 15
    if "data-lucide" in lower:
        score += 8
    if "<textarea" in lower:
        score += 6
    if "<script" in lower:
        score += 4
    score += min(len(html_text) // 3000, 6)
    return score


def score_backend_python(path: Path, source: str) -> int:
    if path == Path(__file__).resolve():
        return -1

    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return 0

    score = 0
    flask_constructor_names: set[str] = set()
    flask_module_aliases: set[str] = set()
    flask_app_names: set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == "flask":
            score += 20
            for alias in node.names:
                if alias.name == "Flask":
                    flask_constructor_names.add(alias.asname or alias.name)

        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "flask":
                    score += 20
                    flask_module_aliases.add(alias.asname or alias.name)

        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            value = node.value
            if not isinstance(value, ast.Call):
                continue

            is_flask_constructor = False
            if isinstance(value.func, ast.Name) and value.func.id in flask_constructor_names:
                is_flask_constructor = True
            elif (
                isinstance(value.func, ast.Attribute)
                and value.func.attr == "Flask"
                and isinstance(value.func.value, ast.Name)
                and value.func.value.id in flask_module_aliases
            ):
                is_flask_constructor = True

            if not is_flask_constructor:
                continue

            score += 25
            assign_targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for target in assign_targets:
                if isinstance(target, ast.Name):
                    flask_app_names.add(target.id)

        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for decorator in node.decorator_list:
                if not isinstance(decorator, ast.Call):
                    continue
                if not isinstance(decorator.func, ast.Attribute) or decorator.func.attr != "route":
                    continue
                if not isinstance(decorator.func.value, ast.Name):
                    continue
                if flask_app_names and decorator.func.value.id not in flask_app_names:
                    continue

                score += 18

                route_value: str | None = None
                if decorator.args and isinstance(decorator.args[0], ast.Constant) and isinstance(decorator.args[0].value, str):
                    route_value = decorator.args[0].value

                if route_value and "/api/" in route_value:
                    score += 20
                if route_value and "/api/scrape" in route_value:
                    score += 45

        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "run":
            if isinstance(node.func.value, ast.Name) and node.func.value.id in flask_app_names:
                score += 8

    return score


def discover_page(root: Path, explicit_path: Path | None, kind: str) -> PageTarget:
    if explicit_path is not None:
        resolved = explicit_path.expanduser().resolve()
        if not resolved.exists():
            raise FileNotFoundError(f"Configured {kind} entry does not exist: {resolved}")
        return PageTarget(kind=kind, entry=resolved)

    html_files = iter_project_files(root, (".html",))
    if not html_files:
        raise FileNotFoundError(f"No HTML files found under {root}")

    scored_candidates: list[tuple[int, int, Path]] = []
    for html_file in html_files:
        try:
            text = load_text(html_file)
        except UnicodeDecodeError:
            continue

        score = score_login_html(html_file, text) if kind == "login" else score_dashboard_html(html_file, text)
        scored_candidates.append((score, len(text), html_file))

    if not scored_candidates:
        raise FileNotFoundError(f"Unable to inspect HTML files for {kind} discovery.")

    score, _, candidate = max(scored_candidates, key=lambda item: (item[0], item[1]))
    if score < 10:
        raise FileNotFoundError(
            f"Unable to confidently discover the {kind} entry page. "
            f"Use --{kind}-entry to point at it explicitly."
        )

    return PageTarget(kind=kind, entry=candidate.resolve())


def discover_backend_file(root: Path, explicit_path: Path | None) -> Path | None:
    if explicit_path is not None:
        resolved = explicit_path.expanduser().resolve()
        if not resolved.exists():
            raise FileNotFoundError(f"Configured backend file does not exist: {resolved}")
        return resolved

    best_match: tuple[int, Path] | None = None
    for py_file in iter_project_files(root, (".py",)):
        try:
            source = load_text(py_file)
        except UnicodeDecodeError:
            continue

        score = score_backend_python(py_file, source)
        if score < 0:
            continue
        if best_match is None or score > best_match[0]:
            best_match = (score, py_file.resolve())

    if best_match is None or best_match[0] < 30:
        return None

    return best_match[1]


def derive_display_name(email: str) -> str:
    local = (email or "").split("@", 1)[0].strip()
    if not local:
        return "Researcher"

    parts = [part for part in local.replace("-", ".").replace("_", ".").split(".") if part]
    if not parts:
        return "Researcher"

    formatted = " ".join(part[:1].upper() + part[1:] for part in parts[:2])
    return formatted or "Researcher"


def sanitize_session(data: dict[str, Any] | None) -> dict[str, str] | None:
    if not isinstance(data, dict):
        return None

    email = str(data.get("email", "")).strip()
    if not email:
        return None

    name = str(data.get("name", "")).strip() or derive_display_name(email)
    initial = str(data.get("initial", "")).strip()[:1].upper() or name[:1].upper() or "R"

    return {
        "email": email,
        "name": name,
        "initial": initial,
    }


def decode_session(cookie_value: str) -> dict[str, str] | None:
    if not cookie_value:
        return None

    try:
        normalized = unquote(cookie_value)
        padded = normalized + "=" * (-len(normalized) % 4)
        raw = base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8")
        return sanitize_session(json.loads(raw))
    except Exception:
        return None


def login_bridge_markup() -> str:
    return f"""
<script>
(function () {{
  const cookieName = {json_for_script(COOKIE_NAME)};
  const storageKey = {json_for_script(STORAGE_KEY)};
  const dashboardUrl = "/dashboard";
  const maxAge = {COOKIE_MAX_AGE};

  const form = document.querySelector("form");
  const emailInput = document.querySelector('input[type="email"], input[name="email"]');
  const passwordInput = document.querySelector('input[type="password"], input[name="password"]');

  function deriveName(email) {{
    const local = (email || "").split("@")[0].trim();
    if (!local) return "Researcher";
    const parts = local.replace(/[-_]/g, ".").split(".").filter(Boolean);
    if (!parts.length) return "Researcher";
    return parts.slice(0, 2).map(function (part) {{
      return part.charAt(0).toUpperCase() + part.slice(1);
    }}).join(" ");
  }}

  function encodeSession(session) {{
    const json = JSON.stringify(session);
    return btoa(unescape(encodeURIComponent(json)))
      .replace(/\\+/g, "-")
      .replace(/\\//g, "_")
      .replace(/=+$/g, "");
  }}

  function writeSession(session) {{
    localStorage.setItem(storageKey, JSON.stringify(session));
    document.cookie = cookieName + "=" + encodeSession(session) +
      "; Max-Age=" + maxAge + "; Path=/; SameSite=Lax";
  }}

  if (!form || !emailInput || !passwordInput) {{
    return;
  }}

  form.addEventListener("submit", function (event) {{
    event.preventDefault();
    event.stopImmediatePropagation();

    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();
    if (!email || !password) {{
      alert("Please enter both email and password.");
      return;
    }}

    const name = deriveName(email);
    writeSession({{
      email: email,
      name: name,
      initial: name.charAt(0).toUpperCase() || "R",
      loggedInAt: new Date().toISOString()
    }});

    window.location.assign(dashboardUrl);
  }}, true);
}})();
</script>
""".strip()


def dashboard_bridge_markup(session: dict[str, str]) -> str:
    session_json = json_for_script(session)
    return f"""
<script>
(function () {{
  const session = {session_json};
  const storageKey = {json_for_script(STORAGE_KEY)};

  try {{
    localStorage.setItem(storageKey, JSON.stringify(session));
  }} catch (error) {{
    // Ignore storage failures and keep the page usable.
  }}

  function applyUserDetails() {{
    const userButton = document.getElementById("user-menu-btn");
    if (userButton) {{
      userButton.textContent = session.initial || "R";
    }}

    const dropdown = document.getElementById("user-dropdown");
    if (!dropdown) {{
      return;
    }}

    const emailText = dropdown.querySelector("span.text-sm.text-gray-300");
    if (emailText) {{
      emailText.textContent = session.email;
    }}

    const greeting = dropdown.querySelector("h2.text-xl.font-medium");
    if (greeting) {{
      greeting.textContent = "Hi, " + (session.name || "Researcher") + "!";
    }}

    const logoutRow = Array.from(dropdown.querySelectorAll("div")).find(function (node) {{
      return node.textContent && node.textContent.includes("Sign out of all accounts");
    }});

    if (logoutRow && !logoutRow.dataset.bridgeBound) {{
      logoutRow.dataset.bridgeBound = "true";
      logoutRow.addEventListener("click", function () {{
        try {{
          localStorage.removeItem(storageKey);
        }} catch (error) {{
          // Ignore storage failures and continue the logout redirect.
        }}
        window.location.assign("/logout");
      }});
    }}
  }}

  if (document.readyState === "loading") {{
    document.addEventListener("DOMContentLoaded", applyUserDetails, {{ once: true }});
  }} else {{
    applyUserDetails();
  }}
}})();
</script>
""".strip()


def is_external_asset_url(value: str) -> bool:
    stripped = value.strip().lower()
    return (
        not stripped
        or stripped.startswith(("http://", "https://", "//", "data:", "mailto:", "tel:", "javascript:", "#"))
    )


def build_asset_route(page: PageTarget, original_value: str) -> str:
    mode = "root" if original_value.startswith("/") else "page"
    relative = original_value[1:] if mode == "root" else original_value
    encoded = quote(relative, safe="/._-~")
    return f"{ASSET_PREFIX}{page.kind}/{mode}/{encoded}"


def rewrite_page_assets(page: PageTarget, html_text: str) -> str:
    rewritten = html_text

    def replace_match(match: re.Match[str]) -> str:
        prefix, value, suffix = match.groups()
        if is_external_asset_url(value):
            return match.group(0)
        return f"{prefix}{build_asset_route(page, value)}{suffix}"

    for pattern in ASSET_TAG_PATTERNS:
        rewritten = pattern.sub(replace_match, rewritten)

    return rewritten


def resolve_asset_path(root: Path, base_dir: Path, relative_path: str) -> Path | None:
    candidate = (base_dir / Path(unquote(relative_path))).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        return None
    return candidate


def is_port_open(host: str, port: int, timeout: float = 0.35) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def wait_for_port(host: str, port: int, timeout: float = 8.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if is_port_open(host, port):
            return True
        time.sleep(0.2)
    return False


def discover_python_executable(root: Path, backend_file: Path | None) -> Path:
    search_roots: list[Path] = []

    if backend_file is not None:
        current = backend_file.parent.resolve()
        while True:
            search_roots.append(current)
            if current == root or current.parent == current:
                break
            current = current.parent

    search_roots.append(root)

    seen: set[Path] = set()
    for search_root in search_roots:
        for env_name in (".venv", "venv"):
            candidate = search_root / env_name / "bin" / "python"
            canonical = candidate.resolve()
            if canonical in seen:
                continue
            seen.add(canonical)
            if candidate.exists():
                return candidate

    return Path(sys.executable).resolve()


def discover_cert_bundle(python_path: Path) -> Path | None:
    try:
        completed = subprocess.run(
            [str(python_path), "-c", "import certifi; print(certifi.where())"],
            capture_output=True,
            text=True,
            timeout=3,
            check=True,
        )
    except (OSError, subprocess.SubprocessError):
        return None

    bundle_path = completed.stdout.strip()
    if not bundle_path:
        return None

    candidate = Path(bundle_path)
    if not candidate.exists():
        return None

    return candidate


def build_backend_bootstrap(backend_file: Path, backend_port: int) -> str:
    backend_path = json.dumps(str(backend_file))
    return "\n".join(
        [
            "import importlib.util",
            "import sys",
            "from pathlib import Path",
            "from flask import Flask",
            f"backend_path = Path({backend_path})",
            "spec = importlib.util.spec_from_file_location('bridge_backend_module', backend_path)",
            "module = importlib.util.module_from_spec(spec)",
            "assert spec is not None and spec.loader is not None",
            "sys.modules[spec.name] = module",
            "spec.loader.exec_module(module)",
            "app = next((value for value in vars(module).values() if isinstance(value, Flask)), None)",
            "if app is None:",
            "    raise SystemExit(f'No Flask app instance found in {backend_path}')",
            f"app.run(port={backend_port}, debug=True, use_reloader=False)",
        ]
    )


def build_script_process_env(python_path: Path, host: str, port: int) -> dict[str, str]:
    env = os.environ.copy()
    env.setdefault("HOST", host)
    env.setdefault("PORT", str(port))

    cert_bundle = discover_cert_bundle(python_path)
    if cert_bundle is not None:
        env.setdefault("SSL_CERT_FILE", str(cert_bundle))
        env.setdefault("REQUESTS_CA_BUNDLE", str(cert_bundle))

    return env


@dataclass(frozen=True)
class SyncLayout:
    root: Path
    login_page: PageTarget
    dashboard_page: PageTarget
    participant_page: PageTarget
    backend_file: Path | None

    def page_for_kind(self, kind: str) -> PageTarget:
        if kind == "login":
            return self.login_page
        if kind == "dashboard":
            return self.dashboard_page
        if kind == "participant":
            return self.participant_page
        raise KeyError(kind)


def build_origin(host: str, port: int) -> str:
    display_host = host
    if host in {"0.0.0.0", "::"}:
        display_host = "127.0.0.1"
    if ":" in display_host and not display_host.startswith("["):
        display_host = f"[{display_host}]"
    return f"http://{display_host}:{port}"


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def score_participant_html(path: Path, html_text: str) -> int:
    lower = html_text.lower()
    score = 0

    if "enter invitation code" in lower:
        score += 30
    if 'id="invitescreen"' in lower or "id='invitescreen'" in lower:
        score += 30
    if 'id="mainpage"' in lower or "id='mainpage'" in lower:
        score += 20
    if 'id="storytrack"' in lower or "id='storytrack'" in lower:
        score += 18
    if 'id="singlepostcontainer"' in lower or "id='singlepostcontainer'" in lower:
        score += 18
    if 'id="postoverlay"' in lower or "id='postoverlay'" in lower:
        score += 12
    if "camera access request" in lower:
        score += 10
    if "participant interface" in lower or "participant" in lower:
        score += 8
    if "log in" in lower or "login" in lower:
        score -= 25

    return score


def discover_participant_page(root: Path, explicit_path: Path | None) -> PageTarget:
    if explicit_path is not None:
        resolved = explicit_path.expanduser().resolve()
        if not resolved.exists():
            raise FileNotFoundError(f"Configured participant entry does not exist: {resolved}")
        return PageTarget(kind="participant", entry=resolved)

    html_files = iter_project_files(root, (".html",))
    if not html_files:
        raise FileNotFoundError(f"No HTML files found under {root}")

    scored_candidates: list[tuple[int, int, Path]] = []
    for html_file in html_files:
        try:
            text = load_text(html_file)
        except UnicodeDecodeError:
            continue

        score = score_participant_html(html_file, text)
        scored_candidates.append((score, len(text), html_file))

    if not scored_candidates:
        raise FileNotFoundError("Unable to inspect HTML files for participant discovery.")

    score, _, candidate = max(scored_candidates, key=lambda item: (item[0], item[1]))
    if score < 15:
        raise FileNotFoundError(
            "Unable to confidently discover the participant page. "
            "Use --participant-entry to point at it explicitly."
        )

    return PageTarget(kind="participant", entry=candidate.resolve())


def discover_sync_layout(
    root: Path,
    login_entry: Path | None,
    dashboard_entry: Path | None,
    participant_entry: Path | None,
    backend_file: Path | None,
) -> SyncLayout:
    login_page = discover_page(root, login_entry, "login")
    dashboard_page = discover_page(root, dashboard_entry, "dashboard")
    participant_page = discover_participant_page(root, participant_entry)

    entries = {login_page.entry, dashboard_page.entry, participant_page.entry}
    if len(entries) != 3:
        raise RuntimeError(
            "The login, dashboard, and participant pages must resolve to three different files. "
            "Use explicit CLI flags to disambiguate them."
        )

    return SyncLayout(
        root=root.resolve(),
        login_page=login_page,
        dashboard_page=dashboard_page,
        participant_page=participant_page,
        backend_file=discover_backend_file(root, backend_file),
    )


def normalize_post_payload(payload: dict[str, Any]) -> dict[str, Any]:
    caption = str(payload.get("caption") or "").strip()
    if not caption:
        raise ValueError("Caption is required before publishing.")

    # Keep the invite code on the published record so the bridge can reuse it
    # later without forcing the participant flow to depend on it right now.
    invite_code = re.sub(r"[^A-Z0-9]", "", str(payload.get("inviteCode") or "").upper())[:8]
    username = str(payload.get("username") or "survey_lab_news").strip() or "survey_lab_news"
    location = str(payload.get("location") or "Sydney, Australia").strip() or "Sydney, Australia"
    image = str(payload.get("image") or "").strip()
    platform = str(payload.get("platform") or "instagram").strip().lower() or "instagram"

    comments_list = payload.get("commentsList")
    if not isinstance(comments_list, list) or not comments_list:
        comments_list = [
            "This post was published from the researcher dashboard.",
            "Participant preview is now reading live published data.",
        ]

    normalized_comments = [str(item).strip() for item in comments_list if str(item).strip()]
    if not normalized_comments:
        normalized_comments = ["This post was published from the researcher dashboard."]

    created_at = str(payload.get("createdAt") or utc_now_iso())
    time_label = str(payload.get("timeLabel") or "JUST NOW").strip() or "JUST NOW"

    return {
        "id": str(uuid.uuid4()),
        "inviteCode": invite_code,
        "version": str(payload.get("version") or "vA"),
        "platform": platform,
        "username": username,
        "location": location,
        "caption": caption,
        "image": image,
        "likes": max(0, int(payload.get("likes") or 0)),
        "comments": max(0, int(payload.get("comments") or 0)),
        "shares": max(0, int(payload.get("shares") or 0)),
        "previewLabel": "Published Image" if image else "[News Image Preview]",
        "avatarLetter": username[:1].upper() or "S",
        "commentsList": normalized_comments,
        "createdAt": created_at,
        "time": time_label,
    }


class PublishedPostStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.lock = threading.Lock()
        self.data = self._load()

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"posts": []}

        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {"posts": []}

        posts = raw.get("posts")
        if isinstance(posts, list):
            return {"posts": posts}

        invites = raw.get("invites")
        if isinstance(invites, dict):
            flattened_posts: list[dict[str, Any]] = []
            for invite_entry in invites.values():
                if not isinstance(invite_entry, dict):
                    continue
                entry_posts = invite_entry.get("posts")
                if isinstance(entry_posts, list):
                    flattened_posts.extend(
                        post for post in entry_posts if isinstance(post, dict)
                    )
            flattened_posts.sort(key=lambda post: str(post.get("createdAt") or ""))
            return {"posts": flattened_posts}

        return {"posts": []}

    def _save(self) -> None:
        self.path.write_text(
            json.dumps(self.data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def publish(self, payload: dict[str, Any]) -> dict[str, Any]:
        post = normalize_post_payload(payload)

        with self.lock:
            posts = self.data.setdefault("posts", [])
            posts.append(post)
            self._save()

            return {
                "postCount": len(posts),
                "post": post,
            }

    def get_posts(self, invite_code: str | None = None) -> dict[str, Any]:
        with self.lock:
            posts = list(self.data.get("posts", []))

            # When an invite code is provided, only expose the posts published
            # under that code so the participant entry step has a real purpose.
            normalized_invite = re.sub(r"[^A-Z0-9]", "", str(invite_code or "").upper())[:8]
            if normalized_invite:
                posts = [
                    post
                    for post in posts
                    if re.sub(r"[^A-Z0-9]", "", str(post.get("inviteCode") or "").upper())[:8] == normalized_invite
                ]

            return {
                "posts": posts,
                "postCount": len(posts),
            }


def dashboard_publish_markup(participant_entry_url: str) -> str:
    participant_entry_url_json = json_for_script(participant_entry_url)
    script = """
<script>
(function () {
  const publishApi = "/api/publish";
  const participantEntryUrl = __PARTICIPANT_ENTRY_URL__;
  const inviteCodeStorageKey = "__page_connection_invite_code__";

  function findPublishButton() {
    return Array.from(document.querySelectorAll("button")).find(function (button) {
      return button.textContent && button.textContent.includes("Publish Survey Link");
    });
  }

  function findInviteCodeButton() {
    return document.getElementById("btn-generate-code");
  }

  function findInviteCodeDisplay() {
    return document.getElementById("invite-code-display");
  }

  // Invite codes are generated only from the dashboard button so researchers
  // can decide exactly when to mint or rotate a participant code.
  function generateInviteCode() {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let index = 0; index < 6; index += 1) {
      code += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    }
    return code;
  }

  function readInviteCode() {
    const display = findInviteCodeDisplay();
    const visibleCode = display && display.textContent ? display.textContent.trim().toUpperCase() : "";
    if (visibleCode) {
      return visibleCode;
    }

    try {
      return (localStorage.getItem(inviteCodeStorageKey) || "").trim().toUpperCase();
    } catch (error) {
      return "";
    }
  }

  function writeInviteCode(code) {
    const normalizedCode = (code || "").trim().toUpperCase();
    const display = findInviteCodeDisplay();
    const button = findInviteCodeButton();

    if (display) {
      display.textContent = normalizedCode;
      display.classList.remove("hidden");
    }

    if (button) {
      button.textContent = "Regenerate Invite Code";
    }

    try {
      localStorage.setItem(inviteCodeStorageKey, normalizedCode);
    } catch (error) {
      // Ignore storage failures and keep the dashboard usable.
    }
  }

  // Bind in capture mode so this bridge-owned invite flow overrides the
  // original demo handler without editing the dashboard source files.
  function bindInviteCodeButton() {
    const button = findInviteCodeButton();
    if (!button || button.dataset.inviteBridgeBound === "true") {
      return;
    }

    button.dataset.inviteBridgeBound = "true";
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopImmediatePropagation();
      writeInviteCode(generateInviteCode());
    }, true);
  }

  function hydrateInviteCode() {
    const existingCode = readInviteCode();
    if (existingCode) {
      writeInviteCode(existingCode);
    }
  }

  function buildPublishPayload(inviteCode) {
    const currentData = surveyState.versions[surveyState.currentVersion];

    return {
      inviteCode: inviteCode,
      version: surveyState.currentVersion,
      platform: currentData.platform,
      caption: currentData.caption,
      image: currentData.image || "",
      likes: currentData.likes || 0,
      comments: currentData.comments || 0,
      shares: currentData.shares || 0,
      username: "survey_lab_news",
      location: "Sydney, Australia",
      commentsList: [
        "This post was published from the researcher dashboard.",
        "Participant preview is now reading live published data."
      ],
      createdAt: new Date().toISOString(),
      timeLabel: "JUST NOW"
    };
  }

  function buildParticipantUrl(inviteCode) {
    const normalizedInvite = String(inviteCode || "").trim().toUpperCase();
    if (!normalizedInvite) {
      return participantEntryUrl;
    }
    return participantEntryUrl + "?invite=" + encodeURIComponent(normalizedInvite);
  }

  async function copyToClipboard(text) {
    if (!navigator.clipboard || !navigator.clipboard.writeText) {
      return false;
    }

    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (error) {
      return false;
    }
  }

  const publishBtn = findPublishButton();
  bindInviteCodeButton();
  hydrateInviteCode();

  if (!publishBtn || publishBtn.dataset.publishBridgeBound === "true") {
    return;
  }
  publishBtn.dataset.publishBridgeBound = "true";

  publishBtn.addEventListener("click", async function (event) {
    event.preventDefault();

    const originalText = publishBtn.innerText;
    publishBtn.innerText = "Publishing...";
    publishBtn.disabled = true;
    publishBtn.classList.add("opacity-75", "cursor-not-allowed");

    try {
      const inviteCode = readInviteCode();
      if (!inviteCode) {
        throw new Error("Please generate an invite code before publishing.");
      }

      const payload = buildPublishPayload(inviteCode);
      const response = await fetch(publishApi, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();
      if (!response.ok || !result.success) {
        throw new Error(result.error || "Publish failed.");
      }

      const participantUrl = buildParticipantUrl(inviteCode);
      await copyToClipboard(participantUrl);
      alert("Successfully posted");
    } catch (error) {
      console.error("Failed to publish post:", error);
      alert("Failed to publish post: " + (error && error.message ? error.message : "Unknown error"));
    } finally {
      publishBtn.innerText = originalText;
      publishBtn.disabled = false;
      publishBtn.classList.remove("opacity-75", "cursor-not-allowed");
    }
  });
})();
</script>
"""
    return script.replace("__PARTICIPANT_ENTRY_URL__", participant_entry_url_json).strip()


def participant_socket_bridge_markup(participant_backend_origin: str) -> str:
    return f"""
<script>
(function () {{
  const participantBackendOrigin = {json_for_script(participant_backend_origin)};

  if (typeof window.io !== "function" || window.io.__cs14BridgeWrapped) {{
    return;
  }}

  const originalIo = window.io;

  function bridgedIo() {{
    if (arguments.length === 0) {{
      return originalIo(participantBackendOrigin, {{
        transports: ["websocket", "polling"]
      }});
    }}
    return originalIo.apply(this, arguments);
  }}

  for (const key in originalIo) {{
    try {{
      bridgedIo[key] = originalIo[key];
    }} catch (error) {{
      // Ignore readonly properties and keep the wrapper lightweight.
    }}
  }}

  bridgedIo.__cs14BridgeWrapped = true;
  window.io = bridgedIo;
  window.__cs14ParticipantBackendOrigin = participantBackendOrigin;
}})();
</script>
""".strip()


def participant_sync_markup() -> str:
    return """
<style>
.bridge-published-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
</style>
<script>
(function () {
  if (typeof postData === "undefined" || typeof renderCurrentPost !== "function" || typeof fillDetail !== "function") {
    return;
  }

  const postsApi = "/api/published-posts";
  const participantInviteStorageKey = "__cs14_page_connection_invite__";

  const originalRenderCurrentPost = renderCurrentPost;
  const originalFillDetail = fillDetail;

  function hydrateFeedImage(postId) {
    const data = postData[postId];
    const box = document.querySelector("#singlePostContainer .preview-image-placeholder");
    if (!box || !data) {
      return;
    }

    box.innerHTML = "";
    if (data.image) {
      const image = document.createElement("img");
      image.src = data.image;
      image.alt = "Published post image";
      image.className = "bridge-published-image";
      box.appendChild(image);
      return;
    }

    box.innerHTML = "<span>" + (data.previewLabel || "[News Image Preview]") + "</span>";
  }

  function hydrateDetailImage(postId) {
    const data = postData[postId];
    const box = document.querySelector(".detail-media-placeholder .preview-image-placeholder");
    if (!box || !data) {
      return;
    }

    box.innerHTML = "";
    if (data.image) {
      const image = document.createElement("img");
      image.src = data.image;
      image.alt = "Published post image";
      image.className = "bridge-published-image";
      box.appendChild(image);
      return;
    }

    const text = document.createElement("span");
    text.textContent = data.previewLabel || "[News Image Preview]";
    box.appendChild(text);
  }

  renderCurrentPost = function (postId) {
    originalRenderCurrentPost(postId);
    hydrateFeedImage(Number(postId));
  };

  fillDetail = function (postId) {
    originalFillDetail(postId);
    hydrateDetailImage(Number(postId));
  };

  function createStoryButtonMarkup(postId) {
    return `
      <div class="story-item">
        <button class="story-button${postId === 1 ? " active" : ""}" type="button" data-post="${postId}">
          <div class="story-avatar-ring">
            <div class="story-avatar">
              <div class="story-avatar-inner">
                <div class="story-avatar-photo">${postId}</div>
              </div>
            </div>
          </div>
          <span class="story-label">Post ${postId}</span>
        </button>
      </div>
    `;
  }

  function rebuildStories(postCount) {
    const pages = [];
    const dynamicStoriesPerPage = typeof storiesPerPage === "number" ? storiesPerPage : 6;
    for (let start = 1; start <= postCount; start += dynamicStoriesPerPage) {
      const end = Math.min(postCount, start + dynamicStoriesPerPage - 1);
      const buttons = [];
      for (let postId = start; postId <= end; postId += 1) {
        buttons.push(createStoryButtonMarkup(postId));
      }
      pages.push('<div class="story-page">' + buttons.join("") + "</div>");
    }

    stT.innerHTML = pages.join("");
  }

  function normalizePost(post, index) {
    const username = (post.username || "survey_lab_news").trim() || "survey_lab_news";
    return {
      username: username,
      location: (post.location || "Sydney, Australia").trim() || "Sydney, Australia",
      time: (post.time || "JUST NOW").trim() || "JUST NOW",
      caption: String(post.caption || "").trim(),
      likes: Number(post.likes || 0),
      comments: Number(post.comments || 0),
      previewLabel: post.image ? "Published Image" : (post.previewLabel || "[News Image Preview]"),
      avatarLetter: (post.avatarLetter || username.charAt(0) || "S").toUpperCase(),
      commentsList: Array.isArray(post.commentsList) && post.commentsList.length
        ? post.commentsList.map(function (item) { return String(item); })
        : ["This post was published from the researcher dashboard."],
      image: String(post.image || "")
    };
  }

  function applyPublishedPosts(posts) {
    const normalizedPosts = posts.map(function (post, index) {
      return normalizePost(post, index + 1);
    });

    Object.keys(postData).forEach(function (key) {
      delete postData[key];
    });

    normalizedPosts.forEach(function (post, index) {
      postData[index + 1] = post;
    });

    totalPages = Math.max(1, Math.ceil(normalizedPosts.length / storiesPerPage));
    rebuildStories(normalizedPosts.length);
    currentPostId = 1;
    storyPage = 0;
    renderCurrentPost(1);
    updateStoryTrack();
    if (typeof closeDetail === "function") {
      closeDetail();
    }
  }

  function normalizeInviteCode(value) {
    return String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
  }

  function rememberInviteCode(inviteCode) {
    try {
      localStorage.setItem(participantInviteStorageKey, inviteCode);
    } catch (error) {
      // Ignore storage failures and continue the participant flow.
    }

    if (typeof studyData === "object" && studyData) {
      studyData.inviteCode = inviteCode;
    }
  }

  function enterCalibrationFlow(inviteCode) {
    rememberInviteCode(inviteCode);
    if (typeof hide === "function") {
      hide("inviteScreen");
      hide("mainPage");
      show("calScreen");
    } else {
      document.getElementById("inviteScreen").classList.add("hidden");
      document.getElementById("mainPage").classList.add("hidden");
      document.getElementById("calScreen").classList.remove("hidden");
    }
    appPhase = "CAL_WELCOME";
  }

  async function loadPublishedPosts(inviteCode) {
    const response = await fetch(postsApi + "?invite=" + encodeURIComponent(inviteCode));
    const result = await response.json();
    if (!response.ok || !result.success) {
      throw new Error(result.error || "Failed to load published posts.");
    }
    return result;
  }

  async function verifyInviteAndLoadPosts(inviteCode) {
    try {
      const normalizedInvite = normalizeInviteCode(inviteCode);
      if (!normalizedInvite) {
        alert("Please enter an invitation code.");
        return;
      }

      const result = await loadPublishedPosts(normalizedInvite);
      if (!result.posts || !result.posts.length) {
        alert("Invalid invitation code or no posts have been published for this code yet.");
        return;
      }

      applyPublishedPosts(result.posts);
      enterCalibrationFlow(normalizedInvite);
    } catch (error) {
      console.error("Failed to load published posts:", error);
      alert("Could not load published posts: " + (error && error.message ? error.message : "Unknown error"));
    }
  }

  const inviteInputEl = document.getElementById("inviteInput");
  const verifyInviteBtnEl = document.getElementById("verifyInviteBtn");
  if (!inviteInputEl || !verifyInviteBtnEl) {
    return;
  }

  // Intercept the CS14 entry button so the page keeps its original invite +
  // calibration flow while swapping the placeholder posts for bridge data.
  verifyInviteBtnEl.addEventListener("click", function (event) {
    event.preventDefault();
    event.stopImmediatePropagation();
    verifyInviteAndLoadPosts(inviteInputEl.value);
  }, true);

  inviteInputEl.addEventListener("keydown", function (event) {
    if (event.key !== "Enter") {
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    verifyInviteAndLoadPosts(inviteInputEl.value);
  }, true);

  try {
    const queryInvite = normalizeInviteCode(new URLSearchParams(window.location.search).get("invite") || "");
    const rememberedInvite = normalizeInviteCode(localStorage.getItem(participantInviteStorageKey) || "");
    const initialInvite = queryInvite || rememberedInvite;
    if (initialInvite) {
      inviteInputEl.value = initialInvite;
    }
  } catch (error) {
    // Ignore storage failures and keep the entry screen usable.
  }
})();
</script>
""".strip()


class SyncAppState:
    def __init__(
        self,
        layout: SyncLayout,
        backend_port: int,
        auto_start_backend: bool,
        participant_backend_file: Path | None,
        participant_backend_port: int,
        auto_start_participant_backend: bool,
        store_path: Path,
        host: str,
        researcher_origin: str,
        participant_origin: str,
        participant_backend_origin: str,
    ) -> None:
        self.layout = layout
        self.backend_port = backend_port
        self.auto_start_backend = auto_start_backend
        self.participant_backend_file = participant_backend_file
        self.participant_backend_port = participant_backend_port
        self.auto_start_participant_backend = auto_start_participant_backend
        self.store = PublishedPostStore(store_path)
        self.host = host
        self.researcher_origin = researcher_origin
        self.participant_origin = participant_origin
        self.participant_backend_origin = participant_backend_origin
        self.backend_process: subprocess.Popen[str] | None = None
        self.backend_warning: str | None = None
        self.participant_backend_process: subprocess.Popen[str] | None = None
        self.participant_backend_warning: str | None = None

    def ensure_backend(self) -> None:
        if is_port_open("127.0.0.1", self.backend_port):
            return

        if not self.auto_start_backend:
            return

        if self.layout.backend_file is None:
            self.backend_warning = (
                "No backend file was discovered automatically. "
                "Dashboard scraping will stay unavailable until something is serving on the backend port."
            )
            return

        python_path = discover_python_executable(self.layout.root, self.layout.backend_file)
        backend_bootstrap = build_backend_bootstrap(self.layout.backend_file, self.backend_port)
        child_env = build_script_process_env(python_path, self.host, self.backend_port)

        self.backend_process = subprocess.Popen(
            [str(python_path), "-c", backend_bootstrap],
            cwd=str(self.layout.backend_file.parent),
            env=child_env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )

        if not wait_for_port("127.0.0.1", self.backend_port):
            stderr_output = ""
            if self.backend_process.poll() is not None and self.backend_process.stderr is not None:
                stderr_output = self.backend_process.stderr.read().strip()

            self.backend_warning = (
                f"Auto-starting the backend on port {self.backend_port} did not succeed. "
                "The bridge will still run, but scraping will stay unavailable."
            )
            if stderr_output:
                self.backend_warning += f" Backend error: {stderr_output}"

            self.shutdown_backend()
            self.backend_process = None

    def ensure_participant_backend(self) -> None:
        if is_port_open("127.0.0.1", self.participant_backend_port):
            return

        if not self.auto_start_participant_backend:
            return

        if self.participant_backend_file is None:
            self.participant_backend_warning = (
                "No participant backend file was configured. "
                "The CS14 participant page will load, but calibration and live eye tracking will stay unavailable."
            )
            return

        python_path = discover_python_executable(self.layout.root, self.participant_backend_file)
        child_env = build_script_process_env(python_path, self.host, self.participant_backend_port)

        self.participant_backend_process = subprocess.Popen(
            [str(python_path), str(self.participant_backend_file)],
            cwd=str(self.participant_backend_file.parent),
            env=child_env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )

        if not wait_for_port("127.0.0.1", self.participant_backend_port, timeout=15.0):
            stderr_output = ""
            if self.participant_backend_process.poll() is not None and self.participant_backend_process.stderr is not None:
                stderr_output = self.participant_backend_process.stderr.read().strip()

            self.participant_backend_warning = (
                f"Auto-starting the participant backend on port {self.participant_backend_port} did not succeed. "
                "The CS14 participant page will still render, but camera calibration and Socket.IO tracking will stay unavailable."
            )
            if stderr_output:
                self.participant_backend_warning += f" Backend error: {stderr_output}"

            self.shutdown_participant_backend()
            self.participant_backend_process = None

    def ensure_backends(self) -> None:
        self.ensure_backend()
        self.ensure_participant_backend()

    def shutdown_backend(self) -> None:
        if not self.backend_process:
            return

        if self.backend_process.poll() is not None:
            return

        self.backend_process.terminate()
        try:
            self.backend_process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.backend_process.kill()
            self.backend_process.wait(timeout=3)

    def shutdown_participant_backend(self) -> None:
        if not self.participant_backend_process:
            return

        if self.participant_backend_process.poll() is not None:
            return

        self.participant_backend_process.terminate()
        try:
            self.participant_backend_process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.participant_backend_process.kill()
            self.participant_backend_process.wait(timeout=3)

    def shutdown_backends(self) -> None:
        self.shutdown_backend()
        self.shutdown_participant_backend()


class BaseSyncRequestHandler(BaseHTTPRequestHandler):
    server_version = "PublishSyncBridge/2.0"

    @property
    def app_state(self) -> SyncAppState:
        return self.server.app_state  # type: ignore[attr-defined]

    @property
    def server_label(self) -> str:
        return self.server.server_label  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stdout.write(f"[publish-sync:{self.server_label}] {self.address_string()} - {fmt % args}\n")

    def serve_asset(self, request_path: str) -> None:
        tail = request_path[len(ASSET_PREFIX):]
        parts = tail.split("/", 2)
        if len(parts) != 3:
            self.send_error(HTTPStatus.NOT_FOUND, "Asset not found")
            return

        page_kind, mode, relative_path = parts
        try:
            page = self.app_state.layout.page_for_kind(page_kind)
        except KeyError:
            self.send_error(HTTPStatus.NOT_FOUND, "Asset not found")
            return

        base_dir = self.app_state.layout.root if mode == "root" else page.directory
        asset_path = resolve_asset_path(self.app_state.layout.root, base_dir, relative_path)
        if asset_path is None or not asset_path.exists() or not asset_path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND, "Asset not found")
            return

        self.serve_file(asset_path)

    def read_json_body(self) -> dict[str, Any]:
        content_length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(content_length)
        parsed = json.loads(raw_body.decode("utf-8"))
        if not isinstance(parsed, dict):
            raise ValueError("JSON body must be an object.")
        return parsed

    def serve_file(self, path: Path) -> None:
        content_type, _ = mimetypes.guess_type(str(path))
        body = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html_text: str) -> None:
        body = html_text.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, payload: dict[str, Any], status: HTTPStatus) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def redirect(self, location: str) -> None:
        self.send_response(HTTPStatus.FOUND)
        self.send_header("Location", location)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()


class ResearcherRequestHandler(BaseSyncRequestHandler):
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path in {"/", "/login"}:
            self.serve_login_page()
            return

        if path == "/dashboard":
            session = self.get_session()
            if not session:
                self.redirect("/login")
                return
            self.serve_dashboard_page(session)
            return

        if path == "/logout":
            self.handle_logout()
            return

        if path.startswith(ASSET_PREFIX):
            self.serve_asset(path)
            return

        self.send_error(HTTPStatus.NOT_FOUND, "File not found")

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/publish":
            self.handle_publish()
            return

        self.send_error(HTTPStatus.NOT_FOUND, "File not found")

    def get_session(self) -> dict[str, str] | None:
        raw_cookie = self.headers.get("Cookie")
        if not raw_cookie:
            return None

        cookie = SimpleCookie()
        try:
            cookie.load(raw_cookie)
        except Exception:
            return None

        morsel = cookie.get(COOKIE_NAME)
        if morsel is None:
            return None

        return decode_session(morsel.value)

    def serve_login_page(self) -> None:
        page = self.app_state.layout.login_page
        html_text = rewrite_page_assets(page, load_text(page.entry))
        html_text = inject_before_body_end(html_text, login_bridge_markup())
        self.send_html(html_text)

    def serve_dashboard_page(self, session: dict[str, str]) -> None:
        page = self.app_state.layout.dashboard_page
        html_text = rewrite_page_assets(page, load_text(page.entry))
        html_text = inject_before_body_end(html_text, dashboard_bridge_markup(session))
        html_text = inject_before_body_end(
            html_text,
            dashboard_publish_markup(self.app_state.participant_origin),
        )
        self.send_html(html_text)

    def handle_publish(self) -> None:
        session = self.get_session()
        if not session:
            self.send_json({"success": False, "error": "You must be logged in to publish."}, HTTPStatus.UNAUTHORIZED)
            return

        try:
            payload = self.read_json_body()
            result = self.app_state.store.publish(payload)
        except ValueError as exc:
            self.send_json({"success": False, "error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        except json.JSONDecodeError:
            self.send_json({"success": False, "error": "Invalid JSON payload."}, HTTPStatus.BAD_REQUEST)
            return

        self.send_json(
            {
                "success": True,
                "postCount": result["postCount"],
                "post": result["post"],
            },
            HTTPStatus.CREATED,
        )

    def handle_logout(self) -> None:
        self.send_response(HTTPStatus.FOUND)
        self.send_header("Location", "/login")
        self.send_header(
            "Set-Cookie",
            f"{COOKIE_NAME}=; Max-Age=0; Path=/; SameSite=Lax",
        )
        self.send_header("Cache-Control", "no-store")
        self.end_headers()


class ParticipantRequestHandler(BaseSyncRequestHandler):
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path in {"/", PARTICIPANT_ROUTE}:
            self.serve_participant_page()
            return

        if path == "/api/published-posts":
            self.handle_get_published_posts()
            return

        if path.startswith(ASSET_PREFIX):
            self.serve_asset(path)
            return

        self.send_error(HTTPStatus.NOT_FOUND, "File not found")

    def serve_participant_page(self) -> None:
        page = self.app_state.layout.participant_page
        html_text = rewrite_page_assets(page, load_text(page.entry))
        html_text = inject_before_head_end(
            html_text,
            participant_socket_bridge_markup(self.app_state.participant_backend_origin),
        )
        html_text = inject_before_body_end(html_text, participant_sync_markup())
        self.send_html(html_text)

    def handle_get_published_posts(self) -> None:
        parsed = urlparse(self.path)
        invite_code = parse_qs(parsed.query).get("invite", [""])[0]
        result = self.app_state.store.get_posts(invite_code=invite_code)
        self.send_json(
            {
                "success": True,
                "postCount": result["postCount"],
                "posts": result["posts"],
            },
            HTTPStatus.OK,
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run separate researcher and participant bridge servers without editing the original frontend source files.",
    )
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind the bridge server to.")
    parser.add_argument("--researcher-port", default=8020, type=int, help="Port for the researcher server.")
    parser.add_argument("--participant-port", default=8021, type=int, help="Port for the participant server.")
    parser.add_argument("--backend-port", default=5001, type=int, help="Port expected by dashboard scraping.")
    parser.add_argument(
        "--participant-backend-port",
        default=5050,
        type=int,
        help="Port used by the CS14 participant backend for calibration and Socket.IO.",
    )
    parser.add_argument("--login-entry", type=Path, help="Optional explicit path to the login HTML entry file.")
    parser.add_argument("--dashboard-entry", type=Path, help="Optional explicit path to the dashboard HTML entry file.")
    parser.add_argument(
        "--participant-entry",
        type=Path,
        default=DEFAULT_CS14_PARTICIPANT_ENTRY,
        help="Participant HTML entry file. Defaults to the CS14 participant page.",
    )
    parser.add_argument("--backend-file", type=Path, help="Optional explicit path to the Flask backend Python file.")
    parser.add_argument(
        "--participant-backend-file",
        type=Path,
        default=DEFAULT_CS14_BACKEND_FILE,
        help="Participant backend Python file. Defaults to the CS14 Flask-SocketIO app.",
    )
    parser.add_argument("--store-file", type=Path, default=STORE_PATH, help="Local JSON file used to persist published posts.")
    parser.add_argument("--no-backend", action="store_true", help="Do not auto-start the Flask backend.")
    parser.add_argument(
        "--no-participant-backend",
        action="store_true",
        help="Do not auto-start the CS14 participant backend.",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    port_values = {
        "--researcher-port": args.researcher_port,
        "--participant-port": args.participant_port,
        "--backend-port": args.backend_port,
        "--participant-backend-port": args.participant_backend_port,
    }
    duplicate_ports = {
        port
        for port in port_values.values()
        if list(port_values.values()).count(port) > 1
    }
    if duplicate_ports:
        repeated = ", ".join(str(port) for port in sorted(duplicate_ports))
        parser.error(f"All server and backend ports must be different. Repeated: {repeated}.")

    participant_backend_file = None
    if args.participant_backend_file is not None:
        participant_backend_file = args.participant_backend_file.expanduser().resolve()
        if not participant_backend_file.exists():
            parser.error(f"--participant-backend-file does not exist: {participant_backend_file}")

    layout = discover_sync_layout(
        ROOT_DIR,
        login_entry=args.login_entry,
        dashboard_entry=args.dashboard_entry,
        participant_entry=args.participant_entry,
        backend_file=args.backend_file,
    )

    researcher_origin = build_origin(args.host, args.researcher_port)
    participant_origin = build_origin(args.host, args.participant_port)
    participant_backend_origin = build_origin(args.host, args.participant_backend_port)

    app_state = SyncAppState(
        layout=layout,
        backend_port=args.backend_port,
        auto_start_backend=not args.no_backend,
        participant_backend_file=participant_backend_file,
        participant_backend_port=args.participant_backend_port,
        auto_start_participant_backend=not args.no_participant_backend,
        store_path=args.store_file.expanduser().resolve(),
        host=args.host,
        researcher_origin=researcher_origin,
        participant_origin=participant_origin,
        participant_backend_origin=participant_backend_origin,
    )
    app_state.ensure_backends()

    researcher_httpd = ThreadingHTTPServer((args.host, args.researcher_port), ResearcherRequestHandler)
    participant_httpd = ThreadingHTTPServer((args.host, args.participant_port), ParticipantRequestHandler)
    researcher_httpd.app_state = app_state  # type: ignore[attr-defined]
    participant_httpd.app_state = app_state  # type: ignore[attr-defined]
    researcher_httpd.server_label = "researcher"  # type: ignore[attr-defined]
    participant_httpd.server_label = "participant"  # type: ignore[attr-defined]

    servers = [researcher_httpd, participant_httpd]
    threads: list[threading.Thread] = []
    for server, name in (
        (researcher_httpd, "researcher-server"),
        (participant_httpd, "participant-server"),
    ):
        thread = threading.Thread(target=server.serve_forever, name=name, daemon=True)
        thread.start()
        threads.append(thread)

    def shutdown_handler(signum: int, frame: Any) -> None:
        raise KeyboardInterrupt

    previous_sigint = signal.getsignal(signal.SIGINT)
    previous_sigterm = signal.getsignal(signal.SIGTERM)
    signal.signal(signal.SIGINT, shutdown_handler)
    signal.signal(signal.SIGTERM, shutdown_handler)

    try:
        print("CS14 page-connection bridge running in dual-server mode")
        print(f"Discovered login page: {layout.login_page.entry}")
        print(f"Discovered dashboard page: {layout.dashboard_page.entry}")
        print(f"Discovered participant page: {layout.participant_page.entry}")
        if layout.backend_file is not None:
            print(f"Discovered researcher backend file: {layout.backend_file}")
        else:
            print("Discovered researcher backend file: none")
        if app_state.participant_backend_file is not None:
            print(f"Configured participant backend file: {app_state.participant_backend_file}")
        else:
            print("Configured participant backend file: none")
        if app_state.backend_warning:
            print(f"Researcher backend warning: {app_state.backend_warning}")
        if app_state.participant_backend_warning:
            print(f"Participant backend warning: {app_state.participant_backend_warning}")
        print(f"Published post store: {app_state.store.path}")
        print("Researcher server:")
        print(f"  Entry    {researcher_origin}/login")
        print(f"  Dashboard {researcher_origin}/dashboard")
        print("  API      POST /api/publish")
        print(f"  Scrape   http://127.0.0.1:{args.backend_port}/api/scrape")
        print("Participant server:")
        print(f"  Entry    {participant_origin}/")
        print("  API      GET  /api/published-posts")
        print("Participant note:")
        print("  The CS14 calibration and Socket.IO backend runs internally.")
        print("  Open only the participant entry above in the browser.")
        while True:
            signal.pause()
    except KeyboardInterrupt:
        print("\nStopping publish-sync bridge...")
    finally:
        for server in servers:
            server.shutdown()
        for server in servers:
            server.server_close()
        for thread in threads:
            thread.join(timeout=1)
        app_state.shutdown_backends()
        signal.signal(signal.SIGINT, previous_sigint)
        signal.signal(signal.SIGTERM, previous_sigterm)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
