/**
 * 控制遮罩层或弹窗的显示与隐藏
 * @param {HTMLElement | null} overlay
 * @param {boolean} show
 */
function setOverlayVisible(overlay, show) {
  if (!overlay) return;
  overlay.classList.toggle("hidden", !show);
}

/* =========================
 * 页面元素获取
 * ========================= */
const inviteScreen = document.getElementById("inviteScreen");
const mainPage = document.getElementById("mainPage");
const verifyInviteBtn = document.getElementById("verifyInviteBtn");
const inviteInput = document.getElementById("inviteInput");

const cameraPermissionOverlay = document.getElementById("cameraPermissionOverlay");
const allowCameraBtn = document.getElementById("allowCameraBtn");
const denyCameraBtn = document.getElementById("denyCameraBtn");

const cameraOverlay = document.getElementById("cameraOverlay");
const calibrationCompleteBtn = document.getElementById("calibrationCompleteBtn");

const postOverlay = document.getElementById("postOverlay");
const openPostButtons = document.querySelectorAll(".open-post-modal");
const closePostButtons = document.querySelectorAll(".close-post-modal");
const commentButtons = document.querySelectorAll(".comment-btn[data-post]");

const detailUsername = document.getElementById("detailUsername");
const detailTime = document.getElementById("detailTime");
const detailCaptionUser = document.getElementById("detailCaptionUser");
const detailCaptionText = document.getElementById("detailCaptionText");
const detailLikeCount = document.getElementById("detailLikeCount");
const detailCommentCount = document.getElementById("detailCommentCount");
const detailMediaText = document.getElementById("detailMediaText");

const storyTrack = document.getElementById("storyTrack");
const storyPrevBtn = document.getElementById("storyPrevBtn");
const storyNextBtn = document.getElementById("storyNextBtn");

/* =========================
 * 帖子数据
 * ========================= */
const postData = {
  1: {
    username: "username_01",
    time: "2h ago",
    caption: "This is placeholder content for post 1.",
    likes: 1284,
    comments: 24,
  },
  2: {
    username: "username_02",
    time: "5h ago",
    caption: "This is placeholder content for post 2.",
    likes: 892,
    comments: 13,
  },
  3: {
    username: "username_03",
    time: "1d ago",
    caption: "This is placeholder content for post 3.",
    likes: 761,
    comments: 9,
  },
  4: {
    username: "username_04",
    time: "3h ago",
    caption: "This is placeholder content for post 4.",
    likes: 1450,
    comments: 31,
  },
  5: {
    username: "username_05",
    time: "6h ago",
    caption: "This is placeholder content for post 5.",
    likes: 502,
    comments: 7,
  },
  6: {
    username: "username_06",
    time: "9h ago",
    caption: "This is placeholder content for post 6.",
    likes: 633,
    comments: 15,
  },
  7: {
    username: "username_07",
    time: "11h ago",
    caption: "This is placeholder content for post 7.",
    likes: 1102,
    comments: 22,
  },
  8: {
    username: "username_08",
    time: "13h ago",
    caption: "This is placeholder content for post 8.",
    likes: 978,
    comments: 19,
  },
  9: {
    username: "username_09",
    time: "1d ago",
    caption: "This is placeholder content for post 9.",
    likes: 356,
    comments: 6,
  },
  10: {
    username: "username_10",
    time: "2d ago",
    caption: "This is placeholder content for post 10.",
    likes: 1604,
    comments: 44,
  },
  11: {
    username: "username_11",
    time: "2d ago",
    caption: "This is placeholder content for post 11.",
    likes: 421,
    comments: 8,
  },
  12: {
    username: "username_12",
    time: "3d ago",
    caption: "This is placeholder content for post 12.",
    likes: 705,
    comments: 17,
  },
};

/* =========================
 * 状态变量
 * ========================= */
let currentDetailPostId = 1;
let storyPage = 0;
const storiesPerPage = 6;

/* =========================
 * 工具函数
 * ========================= */

/**
 * 数字格式化为千分位显示
 * @param {number} value
 * @returns {string}
 */
function formatCount(value) {
  return value.toLocaleString();
}

/**
 * 播放点赞数浮动动画
 * @param {HTMLElement | null} floatEl
 * @param {boolean} increment
 */
function animateCount(floatEl, increment) {
  if (!floatEl) return;

  floatEl.textContent = increment ? "+1" : "-1";
  floatEl.classList.remove("show-up", "show-down");

  /* 强制浏览器重绘，以便重复触发动画 */
  void floatEl.offsetWidth;

  floatEl.classList.add(increment ? "show-up" : "show-down");
}

/**
 * 将指定帖子的数据填充到详情弹窗中
 * @param {string | number} postId
 */
function populatePostDetail(postId) {
  const data = postData[postId];
  if (!data) return;

  currentDetailPostId = Number(postId);
  detailUsername.textContent = data.username;
  detailTime.textContent = data.time;
  detailCaptionUser.textContent = data.username;
  detailCaptionText.textContent = data.caption;
  detailLikeCount.textContent = formatCount(data.likes);
  detailCommentCount.textContent = formatCount(data.comments);
  detailMediaText.textContent = `Post ${postId} Image Placeholder`;

  const detailLikeBtn = document.querySelector(".detail-like-btn");

  if (detailLikeBtn) {
    const postCard = document.getElementById(`post-${postId}`);
    const sourceLikeBtn = postCard?.querySelector(".like-btn");
    const liked = sourceLikeBtn?.dataset.liked === "true";

    detailLikeBtn.dataset.liked = liked ? "true" : "false";
    detailLikeBtn.classList.toggle("liked", liked);
  }
}

/**
 * 同步主页面帖子中的点赞 UI
 * @param {number} postId
 */
function syncFeedLikeUI(postId) {
  const postCard = document.getElementById(`post-${postId}`);
  if (!postCard) return;

  const likeCountEl = postCard.querySelector(".like-count");
  if (likeCountEl) {
    likeCountEl.textContent = formatCount(postData[postId].likes);
  }
}

/**
 * 同步详情弹窗中的点赞 UI
 * @param {number} postId
 */
function syncDetailLikeUI(postId) {
  if (currentDetailPostId !== Number(postId)) return;

  const detailLikeBtn = document.querySelector(".detail-like-btn");

  if (detailLikeBtn) {
    const postCard = document.getElementById(`post-${postId}`);
    const sourceLikeBtn = postCard?.querySelector(".like-btn");
    const liked = sourceLikeBtn?.dataset.liked === "true";

    detailLikeBtn.dataset.liked = liked ? "true" : "false";
    detailLikeBtn.classList.toggle("liked", liked);
  }

  detailLikeCount.textContent = formatCount(postData[postId].likes);
}

/**
 * 处理主页面帖子点赞逻辑
 * @param {HTMLButtonElement} button
 */
function handleFeedLike(button) {
  const postCard = button.closest(".post-card");
  if (!postCard) return;

  const postId = Number(postCard.dataset.postId);
  const likeCountEl = postCard.querySelector(".like-count");
  const floatEl = postCard.querySelector(".count-float");

  const isLiked = button.dataset.liked === "true";
  const nextLiked = !isLiked;

  button.dataset.liked = nextLiked ? "true" : "false";
  button.classList.toggle("liked", nextLiked);

  postData[postId].likes += nextLiked ? 1 : -1;

  if (likeCountEl) {
    likeCountEl.textContent = formatCount(postData[postId].likes);
  }

  animateCount(floatEl, nextLiked);
  syncDetailLikeUI(postId);
}

/**
 * 处理详情弹窗中的点赞逻辑
 */
function handleDetailLike() {
  const detailLikeBtn = document.querySelector(".detail-like-btn");
  const postId = currentDetailPostId;
  const postCard = document.getElementById(`post-${postId}`);
  const sourceLikeBtn = postCard?.querySelector(".like-btn");
  const sourceFloatEl = postCard?.querySelector(".count-float");
  const detailFloatEl = detailLikeBtn?.closest(".action-group")?.querySelector(".count-float");

  if (!detailLikeBtn || !sourceLikeBtn) return;

  const isLiked = detailLikeBtn.dataset.liked === "true";
  const nextLiked = !isLiked;

  detailLikeBtn.dataset.liked = nextLiked ? "true" : "false";
  detailLikeBtn.classList.toggle("liked", nextLiked);

  sourceLikeBtn.dataset.liked = nextLiked ? "true" : "false";
  sourceLikeBtn.classList.toggle("liked", nextLiked);

  postData[postId].likes += nextLiked ? 1 : -1;

  detailLikeCount.textContent = formatCount(postData[postId].likes);
  syncFeedLikeUI(postId);

  animateCount(sourceFloatEl, nextLiked);
  animateCount(detailFloatEl, nextLiked);
}

/**
 * 打开帖子详情弹窗
 * @param {string | number} postId
 */
function openPostModal(postId) {
  populatePostDetail(postId);
  setOverlayVisible(postOverlay, true);
}

/**
 * 更新 Story 区域的横向偏移
 */
function updateStoryPosition() {
  if (!storyTrack) return;

  const pageWidth = 81 * storiesPerPage + 14 * (storiesPerPage - 1);
  storyTrack.style.transform = `translateX(-${storyPage * pageWidth}px)`;
}

/* =========================
 * 事件绑定
 * ========================= */

/* 邀请码验证按钮点击 */
if (verifyInviteBtn) {
  verifyInviteBtn.addEventListener("click", () => {
    const value = inviteInput?.value.trim() ?? "";

    if (!value) {
      inviteInput.focus();
      return;
    }

    inviteScreen.classList.add("hidden");
    mainPage.classList.remove("hidden");
    setOverlayVisible(cameraPermissionOverlay, true);
  });
}

/* 输入框按下 Enter 时触发验证 */
if (inviteInput) {
  inviteInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      verifyInviteBtn.click();
    }
  });
}

/* 允许摄像头权限 */
if (allowCameraBtn) {
  allowCameraBtn.addEventListener("click", () => {
    setOverlayVisible(cameraPermissionOverlay, false);
    setOverlayVisible(cameraOverlay, true);
  });
}

/* 拒绝摄像头权限 */
if (denyCameraBtn) {
  denyCameraBtn.addEventListener("click", () => {
    setOverlayVisible(cameraPermissionOverlay, false);
  });
}

/* 校准完成 */
if (calibrationCompleteBtn) {
  calibrationCompleteBtn.addEventListener("click", () => {
    setOverlayVisible(cameraOverlay, false);
  });
}

/* 点击帖子图片打开详情弹窗 */
openPostButtons.forEach((button) => {
  button.addEventListener("click", () => {
    openPostModal(button.dataset.post);
  });
});

/* 点击评论按钮打开详情弹窗 */
commentButtons.forEach((button) => {
  button.addEventListener("click", () => {
    openPostModal(button.dataset.post);
  });
});

/* 点击关闭按钮关闭详情弹窗 */
closePostButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setOverlayVisible(postOverlay, false);
  });
});

/* 点击详情弹窗遮罩关闭详情弹窗 */
if (postOverlay) {
  postOverlay.addEventListener("click", (event) => {
    if (event.target === postOverlay) {
      setOverlayVisible(postOverlay, false);
    }
  });
}

/* 点击摄像头权限遮罩关闭权限弹窗 */
if (cameraPermissionOverlay) {
  cameraPermissionOverlay.addEventListener("click", (event) => {
    if (event.target === cameraPermissionOverlay) {
      setOverlayVisible(cameraPermissionOverlay, false);
    }
  });
}

/* 按下 Escape 关闭部分弹窗 */
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    setOverlayVisible(postOverlay, false);
    setOverlayVisible(cameraPermissionOverlay, false);
  }
});

/* 主页面点赞按钮绑定 */
document.querySelectorAll(".post-card .like-btn").forEach((button) => {
  button.addEventListener("click", () => handleFeedLike(button));
});

/* 详情弹窗点赞按钮绑定 */
const detailLikeBtn = document.querySelector(".detail-like-btn");
if (detailLikeBtn) {
  detailLikeBtn.addEventListener("click", handleDetailLike);
}

/* Story 按钮点击后滚动到对应帖子 */
document.querySelectorAll(".story-button").forEach((button) => {
  button.addEventListener("click", () => {
    const postId = button.dataset.post;
    const targetPost = document.getElementById(`post-${postId}`);

    if (targetPost) {
      targetPost.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  });
});

/* 分享按钮占位逻辑 */
document.querySelectorAll(".share-btn").forEach((button) => {
  button.addEventListener("click", () => {
    alert("Share interaction placeholder");
  });
});

/* 展开 / 收起更多评论 */
document.querySelectorAll(".view-more-btn").forEach((button) => {
  button.addEventListener("click", () => {
    const container = button.closest(".post-comments-preview");
    const extra = container?.querySelector(".extra-comments");
    if (!extra) return;

    const expanded = !extra.classList.contains("hidden");
    extra.classList.toggle("hidden", expanded);
    button.textContent = expanded ? "View more comments" : "Hide more comments";
  });
});

/* Story 向左翻页 */
if (storyPrevBtn) {
  storyPrevBtn.addEventListener("click", () => {
    storyPage = Math.max(0, storyPage - 1);
    updateStoryPosition();
  });
}

/* Story 向右翻页 */
if (storyNextBtn) {
  storyNextBtn.addEventListener("click", () => {
    storyPage = Math.min(1, storyPage + 1);
    updateStoryPosition();
  });
}

/* 初始化 Story 位置 */
updateStoryPosition();